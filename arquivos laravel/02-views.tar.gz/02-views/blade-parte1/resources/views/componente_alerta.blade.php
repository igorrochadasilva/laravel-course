<div class="alert alert-danger">
    <!-- <div class="alert-title">{{ $titulo }}</div> -->
    <!-- <div class="alert-title"><strong> nome </strong> - titulo </div > -->
    {{ $slot }}
</div>
