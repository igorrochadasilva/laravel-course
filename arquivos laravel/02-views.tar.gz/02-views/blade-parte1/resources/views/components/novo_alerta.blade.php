<div class="alert alert-{{$tipo}}">
    
    {{ $slot }}

</div>
