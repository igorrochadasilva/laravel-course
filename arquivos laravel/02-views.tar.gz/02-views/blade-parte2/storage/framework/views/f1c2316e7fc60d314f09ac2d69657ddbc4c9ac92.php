<?php $__env->startSection('secao_produtos'); ?>
    Este é o texto da seção de produtos. 
    <?php if(isset($palavra)): ?>
        Palavra: <?php echo e($palavra); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.meulayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>