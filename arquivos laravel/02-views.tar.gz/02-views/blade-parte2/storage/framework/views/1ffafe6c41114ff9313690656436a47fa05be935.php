<?php $__env->startSection('titulo', 'Minha Página'); ?>

<?php $__env->startSection('barralateral'); ?>
    ##parent-placeholder-ef5132c9d094180abbfaad432716ea56624382e5##

    <p>Essa parte é do FILHO.</p>
    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
    <p>Este é o conteúdo do filho.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>