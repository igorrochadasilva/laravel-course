<?php $__env->startSection('secao_produtos'); ?>

    <h1>Loop - Foreach: </h1> 
    <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <p><?php echo e($p['id']); ?>: <?php echo e($p['nome']); ?> </p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <hr>
    <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <p>
            <?php echo e($p['id']); ?>: <?php echo e($p['nome']); ?> 
            <?php if($loop->first): ?>
                (primeiro)  
            <?php endif; ?>
            <?php if($loop->last): ?>
                (ultimo)  
            <?php endif; ?>
            <span class="badge badge-secondary"><?php echo e($loop->index); ?>  / <?php echo e($loop->count); ?> / <?php echo e($loop->remaining); ?></span>  
            <span class="badge badge-secondary"><?php echo e($loop->iteration); ?>  / <?php echo e($loop->count); ?></span>  
        </p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.meulayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>