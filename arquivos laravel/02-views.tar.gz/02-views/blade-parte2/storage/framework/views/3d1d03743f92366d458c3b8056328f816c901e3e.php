<div class="alert alert-<?php echo e($tipo); ?>">
    
    <?php echo e($slot); ?>


</div>
