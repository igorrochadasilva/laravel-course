<html>
<head>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>


    <?php if(isset($produtos)): ?>

        <?php if(count($produtos) === 0): ?> 
            <h1>Nenhum produto</h1>
        <?php elseif(count($produtos) === 1): ?>
            <h1>1 produto</h1>
        <?php else: ?>
            <h1>Vários produtos</h1>
        <?php endif; ?>

    <?php else: ?>
        <h2>Variável produtos não foi passada como parâmetro</h2>
    <?php endif; ?>

    <?php if(empty($produtos)): ?>
        <h2>Nada em produtos</h2>
    <?php endif; ?>


    <script src="<?php echo e(asset('js/app.js')); ?>" type="text/javascript"></script>

</body>
</html>
