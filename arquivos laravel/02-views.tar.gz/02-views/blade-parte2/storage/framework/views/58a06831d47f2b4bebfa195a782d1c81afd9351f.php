<?php $__env->startSection('secao_produtos'); ?>

    <h1>Loop - For: </h1> 
    <?php for($i=0; $i < $n; $i++): ?> 
        <p>Numero <?php echo e($i); ?> </p>
    <?php endfor; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.meulayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>