<html>
    <head>
        <title>Seu titulo - <?php echo $__env->yieldContent('titulo'); ?></title>
    </head>
    <body>
        <?php $__env->startSection('barralateral'); ?>
            Esta parte da seção é do template PAI. 
        <?php echo $__env->yieldSection(); ?>

        <div>
            <?php echo $__env->yieldContent('conteudo'); ?>
        </div>
    </body>
</html>
