<html>
<head>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <?php $__env->startComponent('components.novo_alerta', ['tipo' => 'danger']); ?>
        <strong>Erro:</strong> Sua mensagem de erro. 
    <?php echo $__env->renderComponent(); ?>

    <?php $__env->startComponent('components.novo_alerta', ['tipo' => 'warning']); ?>
        <strong>Erro:</strong> Sua mensagem de erro. 
    <?php echo $__env->renderComponent(); ?>

    <?php $__env->startComponent('components.novo_alerta', ['tipo' => 'success']); ?>
        <strong>Erro:</strong> Sua mensagem de erro. 
    <?php echo $__env->renderComponent(); ?>

    <?php $__env->startComponent('components.novo_alerta', ['tipo' => 'primary']); ?>
        <strong>Erro:</strong> Sua mensagem de erro. 
    <?php echo $__env->renderComponent(); ?>

    <?php $__env->startComponent('components.novo_alerta', ['tipo' => 'secondary']); ?>
        <strong>Erro:</strong> Sua mensagem de erro. 
    <?php echo $__env->renderComponent(); ?>

    <?php $__env->startComponent('components.novo_alerta', ['tipo' => 'info']); ?>
        <strong>Erro:</strong> Sua mensagem de erro. 
    <?php echo $__env->renderComponent(); ?>

    <?php $__env->startComponent('components.novo_alerta', ['tipo' => 'dark']); ?>
        <strong>Erro:</strong> Sua mensagem de erro. 
    <?php echo $__env->renderComponent(); ?>

    <script src="<?php echo e(asset('js/app.js')); ?>" type="text/javascript"></script>
</body>
</html>
