<?php $__env->startSection('secao_produtos'); ?>
    Você escolheu a opção: 

    <?php if(isset($opcao)): ?>
        <?php switch($opcao):
            case (1): ?>
                <span class="badge badge-primary">Azul</span> 
                <?php break; ?>
            <?php case (2): ?>
                <span class="badge badge-danger">Vermelho</span> 
                <?php break; ?>
            <?php case (3): ?>
                <span class="badge badge-success">Verde</span> 
                <?php break; ?>
            <?php case (4): ?>
                <span class="badge badge-warning">Amarelo</span> 
                <?php break; ?>
            <?php default: ?>
                <span class="badge badge-dark">Outra cor</span> 
        <?php endswitch; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.meulayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>