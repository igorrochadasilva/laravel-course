<div class="alert alert-danger">
    <!-- <div class="alert-title"><?php echo e($titulo); ?></div> -->

    <!-- <div class="alert-title"><strong> nome </strong> - titulo </div > -->
    
    <?php echo e($slot); ?>

    

</div>
