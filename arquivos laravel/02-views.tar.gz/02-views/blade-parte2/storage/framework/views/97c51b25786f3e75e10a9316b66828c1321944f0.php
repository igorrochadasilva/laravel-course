<?php $__env->startSection('secao_produtos'); ?>

<a href="/opcoes/1" class="btn btn-primary btn-sm" role="button" aria-disabled="true">Azul</a>
<a href="/opcoes/2" class="btn btn-danger btn-sm" role="button" aria-disabled="true">Vermelho</a>
<a href="/opcoes/3" class="btn btn-success btn-sm" role="button" aria-disabled="true">Verde</a>
<a href="/opcoes/4" class="btn btn-warning btn-sm" role="button" aria-disabled="true">Amarelo</a>
<a href="/opcoes/10" class="btn btn-light btn-sm" role="button" aria-disabled="true">Branco</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.meulayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>