<html>
<head>
    <!--link href="<?php echo e(URL::to('css/app.css')); ?>" rel="stylesheet"-->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

</head>
<body>
    <!-- acrescentar parametro: ['titulo' => 'Erro fatal', 'nome'=>'Joao' ] -->
    <?php $__env->startComponent('componente_alerta'); ?>

    <!-- 
      Any content not within a slot directive 
      will be passed to the component in the slot variable. 
    -->
    <!--
        <?php $__env->slot('titulo'); ?>
            Erro fatal 
        <?php $__env->endSlot(); ?>
    -->

        <strong>Erro:</strong> Sua mensagem de erro. 
    <?php echo $__env->renderComponent(); ?>

    <script src="<?php echo e(asset('js/app.js')); ?>" type="text/javascript"></script>
    <!--script src="<?php echo e(URL::to('js/app.js')); ?>" type="text/javascript"></script-->

</body>
</html>
