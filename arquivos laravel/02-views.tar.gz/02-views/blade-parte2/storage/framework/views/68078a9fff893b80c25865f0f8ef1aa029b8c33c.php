<html>
<head>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>

    <?php if (! empty(trim($__env->yieldContent('secao_produtos')))): ?>
        <div class="card" style="width: 500px; margin: 10px;">
            <div class="card-body">
                <h5 class="card-title">Produtos</h5>
                <p class="card-text">
                    <?php echo $__env->yieldContent('secao_produtos'); ?>
                </p>
                <a href="#" class="card-link">Informações</a>
                <a href="#" class="card-link">Ajuda</a>
            </div>
        </div>

    <?php endif; ?>

    <script src="<?php echo e(asset('js/app.js')); ?>" type="text/javascript"></script>

</body>
</html>

