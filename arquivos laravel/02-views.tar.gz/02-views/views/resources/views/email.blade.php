<html>
    <body>
        <h1>Seu email é: {{ $email }}</h1>
    </body>
</html>
