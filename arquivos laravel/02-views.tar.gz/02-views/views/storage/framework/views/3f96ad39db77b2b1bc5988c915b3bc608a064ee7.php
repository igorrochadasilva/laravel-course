<html>
    <body>
        <h1>Seu email é: <?php echo e($email); ?></h1>
    </body>
</html>
